# Football Menager PWA v0.3.0

Mobilna wersja Football Menagera przeznaczona głównie na iPhone'a.

## Aktualizacja istniejącej strony Netlify
1. Nie usuwaj aplikacji z iPhone'a i nie czyść danych Safari — sejw jest zapisany lokalnie pod tym samym adresem strony.
2. W Netlify otwórz swój istniejący projekt.
3. Wgraj zawartość folderu `Football_Menager_PWA_v0.3` jako nowy deploy tego SAMEGO projektu.
4. Otwórz aplikację. Service Worker pobierze v0.3; jeśli przez chwilę widzisz starą wersję, zamknij aplikację z przełącznika aplikacji i otwórz ponownie.
5. W `Więcej` numer wersji powinien pokazywać `v0.3.0 build 3`.

## Sejwy
- klucz sejwa pozostał ten sam: `football-menager-career-v1`
- sejw z v0.2 jest migrowany automatycznie
- dla bezpieczeństwa można przed aktualizacją użyć `Więcej -> Eksport`

## DEV
- `Więcej -> Football Menager v0.3.0` — stuknij 7 razy
- licznik odblokowania jest celowo niewidoczny
- po odblokowaniu pojawia się `Panel DEV`
- ATA/POM/OBR/BR w trybie ręcznym są używane bezpośrednio przez silnik meczu

## Ważne
PWA musi działać z HTTPS (np. Netlify), aby instalacja i offline działały poprawnie.
