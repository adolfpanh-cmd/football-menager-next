(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.FM = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '0.3.0';
  const BUILD = 3;
  const SCHEMA_VERSION = 2;

  const POSITIONS = [
    { key: 'GK', label: 'BR' },
    { key: 'DEF', label: 'OBR' },
    { key: 'MID', label: 'POM' },
    { key: 'WING', label: 'SKR' },
    { key: 'ST', label: 'NAP' }
  ];

  const TACTICS = {
    cautious: {
      label: 'Ostrożna', short: 'Niski blok',
      attack: -0.12, midfield: -0.02, defense: 0.13, tempo: 0.82, fatigue: 5,
      desc: 'Mniej ryzyka, ciaśniej w obronie, wolniejsze tempo.'
    },
    balanced: {
      label: 'Zbalansowana', short: 'Kontrola',
      attack: 0, midfield: 0, defense: 0, tempo: 1.00, fatigue: 7,
      desc: 'Równe proporcje między atakiem, środkiem i obroną.'
    },
    pressing: {
      label: 'Pressing', short: 'Wysoki odbiór',
      attack: 0.08, midfield: 0.10, defense: 0.02, tempo: 1.18, fatigue: 10,
      desc: 'Więcej odbiorów i szybsze akcje, ale większe zmęczenie.'
    },
    attacking: {
      label: 'Atak', short: 'Pełne ryzyko',
      attack: 0.20, midfield: 0.04, defense: -0.15, tempo: 1.30, fatigue: 12,
      desc: 'Maksymalna ofensywa kosztem zabezpieczenia tyłów.'
    }
  };

  function uid() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }
  function clamp(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }
  function integer(value, min, max) { return Math.round(clamp(value, min, max)); }
  function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
  function pick(arr) { return arr[randInt(0, arr.length - 1)]; }
  function round1(n) { return Math.round(n * 10) / 10; }

  function money(amount) {
    const n = Number.isFinite(Number(amount)) ? Number(amount) : 0;
    try { return new Intl.NumberFormat('pl-PL', { style:'currency', currency:'PLN', maximumFractionDigits:0 }).format(n); }
    catch (_) { return Math.round(n).toLocaleString('pl-PL') + ' zł'; }
  }
  function moneyCompact(amount) {
    const n = Number.isFinite(Number(amount)) ? Number(amount) : 0;
    const abs = Math.abs(n);
    if (abs >= 1e12) return (n / 1e12).toLocaleString('pl-PL', { maximumFractionDigits:2 }) + ' bln zł';
    if (abs >= 1e9) return (n / 1e9).toLocaleString('pl-PL', { maximumFractionDigits:2 }) + ' mld zł';
    if (abs >= 1e6) return (n / 1e6).toLocaleString('pl-PL', { maximumFractionDigits:1 }) + ' mln zł';
    if (abs >= 1e3) return (n / 1e3).toLocaleString('pl-PL', { maximumFractionDigits:0 }) + ' tys. zł';
    return Math.round(n).toLocaleString('pl-PL') + ' zł';
  }

  function randomPlayer(quality) {
    const first = ['Jakub','Oliwier','Kacper','Mateusz','Igor','Adam','Michał','Filip','Lucas','Kenji','Thiago','Moussa','Luis','Marek','Maks','Szymon','Bartosz','Aleks'];
    const last = ['Mazur','Lis','Wrona','Kowalski','Nowak','Zieliński','Mendes','Nakamura','Ribeiro','Diakite','Oliveira','Stanković','Bąk','Krawiec','Sobczak','Wójcik','Król','Czarnecki'];
    const ovr = integer(quality + randInt(-8, 8), 30, 88);
    const pot = integer(ovr + randInt(3, 22), ovr, 95);
    const value = Math.max(10000, (ovr - 28) * (ovr - 28) * 260);
    return {
      id: uid(), name: pick(first) + ' ' + pick(last), age: randInt(17, 32),
      nationality: pick(['🇵🇱','🇧🇷','🇷🇸','🇯🇵','🇫🇷','🇪🇸','🇩🇪','🇵🇹']), position: pick(POSITIONS).key,
      overall: ovr, potential: pot, morale: randInt(65, 90), fitness: randInt(82, 100),
      value, wage: Math.max(900, Math.round(value / 120))
    };
  }

  function generateSquad(count, quality) {
    const players = [];
    for (let i = 0; i < count; i++) {
      const p = randomPlayer(quality);
      if (i < 2) p.position = 'GK';
      else if (i < 8) p.position = 'DEF';
      else if (i < 14) p.position = 'MID';
      else if (i < 18) p.position = 'WING';
      else p.position = 'ST';
      players.push(p);
    }
    return players;
  }

  function createClub(name, city, stadiumName, capacity, budget, reputation, base) {
    return {
      id: uid(), name, city, stadiumName, stadiumCapacity: capacity, budget, reputation,
      attack: base, midfield: base, defense: base, goalkeeping: base, ratingMode: 'squad',
      played: 0, wins: 0, draws: 0, losses: 0, goalsFor: 0, goalsAgainst: 0, points: 0
    };
  }

  function makeRoundRobin(clubs) {
    if (!clubs || clubs.length < 2 || clubs.length % 2 !== 0) return [];
    const ids = clubs.map(c => c.id);
    const fixed = ids.shift();
    const rotating = ids.slice();
    const fixtures = [];
    const n = clubs.length;
    for (let round = 0; round < n - 1; round++) {
      const lineup = [fixed].concat(rotating);
      for (let i = 0; i < n / 2; i++) {
        const a = lineup[i], b = lineup[n - 1 - i];
        const homeFirst = (round + i) % 2 === 0;
        fixtures.push({
          id: uid(), round: round + 1,
          homeClubId: homeFirst ? a : b, awayClubId: homeFirst ? b : a,
          homeGoals: null, awayGoals: null, played: false
        });
      }
      rotating.unshift(rotating.pop());
    }
    const firstHalf = fixtures.slice();
    firstHalf.forEach(f => fixtures.push({
      id: uid(), round: f.round + (n - 1), homeClubId: f.awayClubId, awayClubId: f.homeClubId,
      homeGoals: null, awayGoals: null, played: false
    }));
    return fixtures;
  }

  function createCareer(input) {
    const name = String(input.name || '').trim() || 'FC Kutas';
    const city = String(input.city || '').trim() || 'Kutaisi';
    const stadium = String(input.stadium || '').trim() || 'Kutas Arena';
    const capacity = integer(input.capacity, 500, 100000);
    const budget = integer(input.budget, 0, 2000000000);
    const user = createClub(name, city, stadium, capacity, budget, 4, 48);
    const rivals = [
      ['KS Borowik','Borów'], ['Orzeł Północ','Północ'], ['LKS Victoria','Victoria'],
      ['Sparta Dolna','Dolna'], ['Grom 1948','Gromowo'], ['Unia Zielona','Zielona'],
      ['Pogoń Nadodrze','Nadodrze'], ['Błękitni','Błękitów'], ['Start Miejski','Miejska']
    ];
    const clubs = [user];
    rivals.forEach((item, index) => {
      const base = 43 + (index % 5) * 2 + randInt(-2, 2);
      const c = createClub(item[0], item[1], 'Stadion Miejski', 1200 + index * 350, 70000 + index * 15000, 3 + Math.floor(index / 3), base);
      c.ratingMode = 'manual';
      c.attack = integer(base + randInt(-3,3), 30, 75);
      c.midfield = integer(base + randInt(-3,3), 30, 75);
      c.defense = integer(base + randInt(-3,3), 30, 75);
      c.goalkeeping = integer(base + randInt(-3,3), 30, 75);
      clubs.push(c);
    });
    return {
      schemaVersion: SCHEMA_VERSION, createdWithVersion: VERSION, userClubId: user.id,
      season: 1, currentRound: 1, clubs, squad: generateSquad(22, 49), transferMarket: generateSquad(42, 52),
      fixtures: makeRoundRobin(clubs), devUnlocked: false, sponsorSigned: false,
      activeMatch: null, lastMatchEvents: [], lastMatchSummary: '', lastMatchStats: null,
      seasonHistory: [], inbox: ['Witaj w klubie. Zarząd oczekuje spokojnego sezonu i rozwoju drużyny.']
    };
  }

  function migrateCareer(career) {
    if (!career || typeof career !== 'object') return null;
    const oldSchema = Number(career.schemaVersion || 1);
    if (!Array.isArray(career.inbox)) career.inbox = [];
    if (!Array.isArray(career.lastMatchEvents)) career.lastMatchEvents = [];
    if (!Array.isArray(career.seasonHistory)) career.seasonHistory = [];
    if (typeof career.devUnlocked !== 'boolean') career.devUnlocked = false;
    if (typeof career.sponsorSigned !== 'boolean') career.sponsorSigned = false;
    if (!('activeMatch' in career)) career.activeMatch = null;
    if (!('lastMatchStats' in career)) career.lastMatchStats = null;
    const club = userClub(career);
    if (club) {
      if (!club.ratingMode) {
        const vals = [club.attack, club.midfield, club.defense, club.goalkeeping].map(Number);
        club.ratingMode = (career.devUnlocked && vals.some(v => v !== 48)) ? 'manual' : 'squad';
      }
    }
    career.schemaVersion = SCHEMA_VERSION;
    if (oldSchema < 2) career.inbox.unshift('Aktualizacja 0.3: przebudowano mecze i interfejs. Twój sejw został zachowany.');
    return career;
  }

  function userClub(state) { return state && state.clubs ? state.clubs.find(c => c.id === state.userClubId) || null : null; }
  function clubById(state, id) { return state.clubs.find(c => c.id === id) || null; }
  function standings(state) {
    if (!state) return [];
    return state.clubs.slice().sort((a,b) => {
      if (a.points !== b.points) return b.points - a.points;
      const gdA = a.goalsFor - a.goalsAgainst, gdB = b.goalsFor - b.goalsAgainst;
      if (gdA !== gdB) return gdB - gdA;
      if (a.goalsFor !== b.goalsFor) return b.goalsFor - a.goalsFor;
      return a.name.localeCompare(b.name, 'pl');
    });
  }
  function nextUserFixture(state) {
    if (!state) return null;
    return state.fixtures.filter(f => !f.played && (f.homeClubId === state.userClubId || f.awayClubId === state.userClubId)).sort((a,b)=>a.round-b.round)[0] || null;
  }

  function averageTop(players, count, fallback) {
    const vals = players.slice().sort((a,b)=>b.overall-a.overall).slice(0,count)
      .map(p => p.overall * (0.78 + p.fitness / 455) * (0.88 + p.morale / 800));
    if (!vals.length) return fallback;
    return vals.reduce((a,b)=>a+b,0)/vals.length;
  }
  function userSquadRatings(state) {
    const club = userClub(state);
    if (club && club.ratingMode === 'manual') {
      const r = { attack:Number(club.attack), midfield:Number(club.midfield), defense:Number(club.defense), goalkeeping:Number(club.goalkeeping) };
      r.overall = (r.attack+r.midfield+r.defense+r.goalkeeping)/4;
      return r;
    }
    if (!state || !state.squad) return { attack:48, midfield:48, defense:48, goalkeeping:48, overall:48 };
    const gk = averageTop(state.squad.filter(p=>p.position==='GK'),1,45);
    const def = averageTop(state.squad.filter(p=>p.position==='DEF'),4,45);
    const mid = averageTop(state.squad.filter(p=>p.position==='MID'),3,45);
    const atk = averageTop(state.squad.filter(p=>p.position==='ST'||p.position==='WING'),3,45);
    return { attack:atk, midfield:mid, defense:def, goalkeeping:gk, overall:(atk+mid+def+gk)/4 };
  }
  function teamFitness(state) {
    if (!state.squad.length) return 0;
    return state.squad.reduce((s,p)=>s+p.fitness,0)/state.squad.length;
  }
  function teamMorale(state) {
    if (!state.squad.length) return 0;
    return state.squad.reduce((s,p)=>s+p.morale,0)/state.squad.length;
  }
  function clubRatings(state, club) {
    if (club.id === state.userClubId) return userSquadRatings(state);
    const r = { attack:club.attack, midfield:club.midfield, defense:club.defense, goalkeeping:club.goalkeeping };
    r.overall = (r.attack+r.midfield+r.defense+r.goalkeeping)/4;
    return r;
  }
  function effectiveStrength(state, club) { return clubRatings(state, club).overall; }

  function bestXI(state) {
    const take = (pos,n) => state.squad.filter(p=>p.position===pos).sort((a,b)=>b.overall-a.overall).slice(0,n);
    const xi = [].concat(take('GK',1), take('DEF',4), take('MID',3), take('WING',2), take('ST',1));
    if (xi.length < 11) {
      const ids = new Set(xi.map(p=>p.id));
      xi.push(...state.squad.filter(p=>!ids.has(p.id)).sort((a,b)=>b.overall-a.overall).slice(0,11-xi.length));
    }
    return xi.slice(0,11);
  }

  function scoutReport(state, opponent) {
    const r = clubRatings(state, opponent);
    const entries = [['atak',r.attack],['środek pola',r.midfield],['obrona',r.defense],['bramkarz',r.goalkeeping]].sort((a,b)=>b[1]-a[1]);
    const strongest = entries[0], weakest = entries[entries.length-1];
    let style = 'zbalansowany';
    if (r.attack-r.defense>5) style='ofensywny';
    else if (r.defense-r.attack>5) style='defensywny';
    else if (r.midfield>=Math.max(r.attack,r.defense)-1) style='oparty na środku pola';
    return { ratings:r, style, strongest:strongest[0], weakest:weakest[0], text:`Rywal gra ${style}. Najmocniejszy element: ${strongest[0]} (${Math.round(strongest[1])}), najsłabszy: ${weakest[0]} (${Math.round(weakest[1])}).` };
  }

  function poisson(lambda) {
    const l=Math.exp(-lambda); let k=0,p=1;
    do { k++; p*=Math.random(); } while(p>l && k<20);
    return Math.max(0,k-1);
  }
  function simulateInstantMatch(state, home, away) {
    const h=effectiveStrength(state,home)+3, a=effectiveStrength(state,away);
    const delta=(h-a)/17;
    return { homeGoals:Math.min(7,poisson(Math.max(.25,1.42+delta))), awayGoals:Math.min(7,poisson(Math.max(.2,1.12-delta))) };
  }

  function applyResult(state, home, away, hg, ag) {
    home.played++; away.played++; home.goalsFor+=hg; home.goalsAgainst+=ag; away.goalsFor+=ag; away.goalsAgainst+=hg;
    if (hg>ag) { home.wins++; home.points+=3; away.losses++; }
    else if (hg<ag) { away.wins++; away.points+=3; home.losses++; }
    else { home.draws++; away.draws++; home.points++; away.points++; }
  }
  function applyMatchFinances(state, fixture) {
    const club=userClub(state); if(!club)return;
    const wages=Math.round(state.squad.reduce((sum,p)=>sum+p.wage,0)/4);
    let income=12000;
    if (fixture.homeClubId===state.userClubId) {
      const occupancy=clamp(.50+club.reputation/35+(Math.random()*.18-.05),.42,.98);
      const attendance=Math.round(club.stadiumCapacity*occupancy);
      income+=attendance*18;
      state.inbox.unshift('Frekwencja: '+attendance.toLocaleString('pl-PL')+' widzów. Przychód meczowy '+money(attendance*18)+'.');
    }
    club.budget+=income-wages;
  }
  function updateSquadAfterMatch(state, tacticKey) {
    const tactic=TACTICS[tacticKey]||TACTICS.balanced;
    state.squad.forEach(p=>{
      const fatigue=randInt(Math.max(2,tactic.fatigue-3),tactic.fatigue+4);
      p.fitness=integer(p.fitness-fatigue,42,100);
      p.morale=integer(p.morale+randInt(-2,3),20,100);
    });
  }
  function recoverSquad(state) { state.squad.forEach(p=>{p.fitness=integer(p.fitness+randInt(2,6),0,100);}); }

  function weightedUserScorer(state) {
    const candidates=state.squad.filter(p=>p.position==='ST'||p.position==='WING'||p.position==='MID').sort((a,b)=>b.overall-a.overall).slice(0,8);
    if(!candidates.length)return null;
    const pool=[];
    candidates.forEach((p,i)=>{for(let k=0;k<Math.max(1,8-i);k++)pool.push(p);});
    return pick(pool);
  }
  function addLiveEvent(match, minute, type, text) {
    match.events.push({ id:uid(), minute, type, text });
    match.events = match.events.slice(-60);
  }
  function startLiveMatch(state, tacticKey) {
    if (state.activeMatch && !state.activeMatch.acknowledged) return state.activeMatch;
    const fixture=nextUserFixture(state); if(!fixture)return null;
    const home=clubById(state,fixture.homeClubId), away=clubById(state,fixture.awayClubId);
    state.activeMatch={
      id:uid(), fixtureId:fixture.id, round:fixture.round, homeClubId:home.id, awayClubId:away.id,
      minute:0, homeGoals:0, awayGoals:0, tactic:TACTICS[tacticKey]?tacticKey:'balanced',
      finished:false, finalized:false, acknowledged:false,
      stats:{home:{shots:0,onTarget:0,xg:0,poss:0,corners:0},away:{shots:0,onTarget:0,xg:0,poss:0,corners:0}},
      events:[]
    };
    addLiveEvent(state.activeMatch,0,'kickoff','Pierwszy gwizdek. Mecz rozpoczęty.');
    return state.activeMatch;
  }

  function liveComponents(state, club, tacticKey) {
    const r=clubRatings(state,club);
    if(club.id!==state.userClubId) return {attack:r.attack,midfield:r.midfield,defense:r.defense,goalkeeping:r.goalkeeping,tempo:1};
    const t=TACTICS[tacticKey]||TACTICS.balanced;
    return {
      attack:r.attack*(1+t.attack), midfield:r.midfield*(1+t.midfield), defense:r.defense*(1+t.defense), goalkeeping:r.goalkeeping,
      tempo:t.tempo
    };
  }

  function simulateMinute(state, match, minute) {
    const home=clubById(state,match.homeClubId), away=clubById(state,match.awayClubId);
    const hc=liveComponents(state,home,match.tactic), ac=liveComponents(state,away,match.tactic);
    const homeMid=hc.midfield+2.5, awayMid=ac.midfield;
    const homePoss=clamp(homeMid/(homeMid+awayMid),.30,.70);
    if(Math.random()<homePoss)match.stats.home.poss++;else match.stats.away.poss++;

    const avgTempo=(hc.tempo+ac.tempo)/2;
    const chanceProb=clamp(.17*avgTempo + Math.abs(hc.attack-ac.attack)/900,.13,.28);
    if(Math.random()<chanceProb){
      const homeThreat=(hc.attack*.58+hc.midfield*.42+2.5)*hc.tempo;
      const awayThreat=(ac.attack*.58+ac.midfield*.42)*ac.tempo;
      const homeAttacks=Math.random()<clamp(homeThreat/(homeThreat+awayThreat),.28,.72);
      const att=homeAttacks?hc:ac, def=homeAttacks?ac:hc;
      const stats=homeAttacks?match.stats.home:match.stats.away;
      stats.shots++;
      let xg=clamp(.07 + Math.random()*.19 + (att.attack-def.defense)/420,.03,.42);
      if(Math.random()<.10){xg=clamp(xg+.16,.08,.62);}
      stats.xg=round1(stats.xg+xg);
      const onTarget=Math.random()<clamp(.40+(att.attack-def.defense)/350,.25,.68);
      if(onTarget)stats.onTarget++;
      const goal=onTarget && Math.random()<clamp(xg*(.72+(att.attack-def.goalkeeping)/260),.025,.55);
      const club=homeAttacks?home:away;
      if(goal){
        if(homeAttacks)match.homeGoals++;else match.awayGoals++;
        let scorer='';
        if(club.id===state.userClubId){const p=weightedUserScorer(state); scorer=p?(' '+p.name):'';}
        addLiveEvent(match,minute,'goal',`⚽ ${club.name}:${scorer || ' gol!'} ${match.homeGoals}:${match.awayGoals}`);
      } else if(onTarget && xg>.16){
        addLiveEvent(match,minute,'save',`🧤 ${club.name} tworzy groźną sytuację, ale bramkarz broni.`);
      } else if(!onTarget && xg>.22){
        addLiveEvent(match,minute,'chance',`🥅 ${club.name} marnuje bardzo dobrą okazję.`);
      } else if(Math.random()<.18){
        addLiveEvent(match,minute,'shot',`↗️ ${club.name} próbuje strzału, bez gola.`);
      }
      if(Math.random()<.13){stats.corners++; if(Math.random()<.25)addLiveEvent(match,minute,'corner',`🚩 Rzut rożny dla ${club.name}.`);}
    }
    if(Math.random()<.012){
      addLiveEvent(match,minute,'card',`🟨 Sędzia sięga po kartkę po ostrym wejściu.`);
    }
    if(Math.random()<.0025){
      addLiveEvent(match,minute,'injury',`🩹 Krótka przerwa po urazie. Zawodnik wraca do gry.`);
    }
  }

  function finalizeLiveMatch(state) {
    const match=state.activeMatch; if(!match || match.finalized)return match;
    const fixture=state.fixtures.find(f=>f.id===match.fixtureId); if(!fixture)return match;
    const home=clubById(state,fixture.homeClubId), away=clubById(state,fixture.awayClubId);
    fixture.homeGoals=match.homeGoals; fixture.awayGoals=match.awayGoals; fixture.played=true;
    applyResult(state,home,away,match.homeGoals,match.awayGoals);
    const round=fixture.round;
    state.fixtures.filter(f=>f.round===round&&!f.played).forEach(f=>{
      const h=clubById(state,f.homeClubId),a=clubById(state,f.awayClubId); if(!h||!a)return;
      const r=simulateInstantMatch(state,h,a); f.homeGoals=r.homeGoals;f.awayGoals=r.awayGoals;f.played=true;applyResult(state,h,a,r.homeGoals,r.awayGoals);
    });
    applyMatchFinances(state,fixture); updateSquadAfterMatch(state,match.tactic); recoverSquad(state);
    state.currentRound=round+1;
    state.lastMatchSummary=home.name+' '+match.homeGoals+':'+match.awayGoals+' '+away.name;
    state.lastMatchEvents=match.events.map(e=>(e.minute>0?e.minute+"' ":'')+e.text);
    const totalPoss=Math.max(1,match.stats.home.poss+match.stats.away.poss);
    state.lastMatchStats={
      home:{shots:match.stats.home.shots,onTarget:match.stats.home.onTarget,xg:match.stats.home.xg,poss:Math.round(match.stats.home.poss/totalPoss*100),corners:match.stats.home.corners},
      away:{shots:match.stats.away.shots,onTarget:match.stats.away.onTarget,xg:match.stats.away.xg,poss:Math.round(match.stats.away.poss/totalPoss*100),corners:match.stats.away.corners}
    };
    state.inbox.unshift('Wynik: '+state.lastMatchSummary);
    if(state.fixtures.every(f=>f.played))state.inbox.unshift('Sezon zakończony. Sprawdź końcową tabelę.');
    state.inbox=state.inbox.slice(0,60);
    match.finalized=true;
    return match;
  }

  function advanceLiveMatch(state, tacticKey, minutes) {
    let match=startLiveMatch(state,tacticKey); if(!match)return {ok:false,message:'Brak meczu do rozegrania.'};
    if(match.finished)return {ok:true,match};
    if(TACTICS[tacticKey])match.tactic=tacticKey;
    const steps=integer(minutes||1,1,120);
    for(let i=0;i<steps && !match.finished;i++){
      match.minute++;
      simulateMinute(state,match,match.minute);
      if(match.minute===45)addLiveEvent(match,45,'half','⏸️ Przerwa. Czas na korekty taktyczne.');
      if(match.minute>=90){
        match.minute=90; match.finished=true;
        addLiveEvent(match,90,'full',`🏁 Koniec meczu: ${clubById(state,match.homeClubId).name} ${match.homeGoals}:${match.awayGoals} ${clubById(state,match.awayClubId).name}`);
        finalizeLiveMatch(state);
      }
    }
    return {ok:true,match};
  }
  function acknowledgeLiveMatch(state) {
    if(state.activeMatch){state.activeMatch.acknowledged=true; state.activeMatch=null;}
  }

  function playNextRound(state, tacticKey) {
    const s=startLiveMatch(state,tacticKey); if(!s)return {ok:false,message:'Sezon jest zakończony.'};
    const r=advanceLiveMatch(state,tacticKey,120); return {ok:r.ok,round:s.round,summary:state.lastMatchSummary,message:r.message||''};
  }

  function buyPlayer(state, playerId) {
    const club=userClub(state),idx=state.transferMarket.findIndex(p=>p.id===playerId);
    if(!club||idx<0)return{ok:false,message:'Zawodnik jest niedostępny.'};
    const player=state.transferMarket[idx]; if(club.budget<player.value)return{ok:false,message:'Za mało pieniędzy.'};
    club.budget-=player.value; state.squad.push(player); state.transferMarket.splice(idx,1);
    state.inbox.unshift('Transfer: '+player.name+' dołącza do klubu za '+money(player.value)+'.');
    return{ok:true,message:player.name+' podpisany.'};
  }
  function sellPlayer(state, playerId) {
    const club=userClub(state),idx=state.squad.findIndex(p=>p.id===playerId);
    if(!club||idx<0)return{ok:false,message:'Nie znaleziono zawodnika.'};
    const player=state.squad[idx],price=Math.max(1000,Math.round(player.value*(.85+Math.random()*.30)));
    club.budget+=price; const sold=state.squad.splice(idx,1)[0]; sold.value=Math.max(10000,Math.round(sold.value*.95)); state.transferMarket.push(sold);
    state.inbox.unshift('Sprzedano '+player.name+' za '+money(price)+'.'); return{ok:true,message:'Sprzedano za '+money(price)+'.'};
  }
  function signSponsor(state) {
    const club=userClub(state); if(!club)return{ok:false,message:'Brak klubu.'};
    if(state.sponsorSigned)return{ok:false,message:'Masz już sponsora na ten sezon.'};
    const amount=80000+club.reputation*25000; club.budget+=amount; state.sponsorSigned=true;
    state.inbox.unshift('Nowy sponsor wpłacił '+money(amount)+'.'); return{ok:true,message:'Sponsor: +'+money(amount)};
  }
  function upgradeStadium(state) {
    const club=userClub(state); if(!club)return{ok:false,message:'Brak klubu.'}; const cost=250000;
    if(club.budget<cost)return{ok:false,message:'Potrzebujesz '+money(cost)+'.'};
    club.budget-=cost;club.stadiumCapacity+=1000;state.inbox.unshift('Rozbudowano stadion o 1000 miejsc.');return{ok:true,message:'Stadion +1000.'};
  }
  function academyIntake(state) {
    const club=userClub(state);if(!club)return{ok:false,message:'Brak klubu.'};const cost=40000;
    if(club.budget<cost)return{ok:false,message:'Potrzebujesz '+money(cost)+'.'};
    club.budget-=cost;const p=randomPlayer(47);p.age=randInt(15,18);p.potential=randInt(Math.max(65,p.overall+10),95);p.value=Math.max(8000,Math.round(p.value/3));state.squad.push(p);
    state.inbox.unshift('Akademia: '+p.name+', '+p.age+' lat, POT '+p.potential+'.');return{ok:true,message:'Nowy talent: '+p.name+' (POT '+p.potential+')'};
  }

  function startNewSeason(state) {
    if(!state.fixtures.every(f=>f.played))return{ok:false,message:'Najpierw dokończ sezon.'};
    const finalTable=standings(state),uc=userClub(state),place=finalTable.findIndex(c=>c.id===state.userClubId)+1;
    state.seasonHistory.unshift({season:state.season,place,points:uc.points,goalsFor:uc.goalsFor,goalsAgainst:uc.goalsAgainst});
    state.season+=1;state.currentRound=1;state.activeMatch=null;
    state.clubs.forEach(c=>{
      c.played=c.wins=c.draws=c.losses=c.goalsFor=c.goalsAgainst=c.points=0;
      if(c.id!==state.userClubId){c.attack=integer(c.attack+randInt(-2,2),32,90);c.midfield=integer(c.midfield+randInt(-2,2),32,90);c.defense=integer(c.defense+randInt(-2,2),32,90);c.goalkeeping=integer(c.goalkeeping+randInt(-2,2),32,90);}
    });
    state.squad.forEach(p=>{p.age++;if(p.age<=24&&p.overall<p.potential)p.overall=integer(p.overall+randInt(0,2),1,p.potential);if(p.age>=31)p.overall=integer(p.overall-randInt(0,1),30,99);p.fitness=randInt(90,100);p.morale=randInt(70,90);});
    state.fixtures=makeRoundRobin(state.clubs);state.transferMarket=state.transferMarket.concat(generateSquad(12,54)).slice(-60);state.sponsorSigned=false;state.lastMatchEvents=[];state.lastMatchSummary='';state.lastMatchStats=null;
    state.inbox.unshift('Rozpoczyna się sezon '+state.season+'. Powodzenia!');return{ok:true,message:'Sezon '+state.season+' rozpoczęty.'};
  }

  function devUpdateClub(state, patch) {
    const club=userClub(state);if(!club)return;
    if('budget'in patch)club.budget=integer(patch.budget,0,999999999999999);
    if('reputation'in patch)club.reputation=integer(patch.reputation,1,20);
    if('stadiumCapacity'in patch)club.stadiumCapacity=integer(patch.stadiumCapacity,100,500000);
    let touchedRating=false;
    ['attack','midfield','defense','goalkeeping'].forEach(k=>{if(k in patch){club[k]=integer(patch[k],1,99);touchedRating=true;}});
    if(touchedRating)club.ratingMode='manual';
  }
  function devUseSquadRatings(state) { const club=userClub(state);if(club)club.ratingMode='squad'; }
  function devUpdatePlayer(state, playerId, patch) {
    const p=state.squad.find(x=>x.id===playerId);if(!p)return;
    if('overall'in patch)p.overall=integer(patch.overall,1,99);
    if('potential'in patch)p.potential=integer(patch.potential,p.overall,99);
    if('morale'in patch)p.morale=integer(patch.morale,0,100);
    if('fitness'in patch)p.fitness=integer(patch.fitness,0,100);
    if('value'in patch)p.value=integer(patch.value,0,999999999999999);
    if('wage'in patch)p.wage=integer(patch.wage,0,999999999);
  }
  function devSetSquad(state, overall, potential) {
    state.squad.forEach(p=>{p.overall=integer(overall,1,99);p.potential=integer(potential,p.overall,99);p.fitness=100;p.morale=100;});
  }
  function devResetSeason(state) {
    state.currentRound=1;state.activeMatch=null;
    state.clubs.forEach(c=>{c.played=c.wins=c.draws=c.losses=c.goalsFor=c.goalsAgainst=c.points=0;});
    state.fixtures=makeRoundRobin(state.clubs);state.lastMatchEvents=[];state.lastMatchSummary='';state.lastMatchStats=null;state.inbox.unshift('DEV: sezon został zresetowany.');
  }

  return {
    VERSION,BUILD,SCHEMA_VERSION,POSITIONS,TACTICS,uid,clamp,integer,randInt,money,moneyCompact,randomPlayer,generateSquad,makeRoundRobin,
    createCareer,migrateCareer,userClub,clubById,standings,nextUserFixture,userSquadRatings,clubRatings,effectiveStrength,teamFitness,teamMorale,bestXI,scoutReport,
    startLiveMatch,advanceLiveMatch,acknowledgeLiveMatch,playNextRound,buyPlayer,sellPlayer,signSponsor,upgradeStadium,academyIntake,startNewSeason,
    devUpdateClub,devUseSquadRatings,devUpdatePlayer,devSetSquad,devResetSeason
  };
});
