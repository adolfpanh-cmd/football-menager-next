# Football Menager — zmiany

## 0.3.0 (build 3)
- całkowicie przebudowany ekran główny: postęp sezonu, następny mecz, forma, tabela i skrzynka
- prawdziwy mecz „na żywo”: zegar 0–90, wynik zmienia się w trakcie, zdarzenia pojawiają się na bieżąco
- statystyki live: strzały, celne, xG, rożne i posiadanie
- prędkość meczu 1× / 4×, pauza i pominięcie do końca
- zmiana taktyki w trakcie meczu wpływa na kolejne minuty symulacji
- raport skauta przed meczem z mocnymi i słabymi stronami rywala
- przeprojektowana kadra i rynek transferowy z miniaturami/awatarami zawodników
- bardziej czytelne karty, budżet skrócony do mln/mld bez ucinania
- ekran zakończenia sezonu ma bezpośredni przycisk rozpoczęcia kolejnego
- DEV: naprawiono ATA/POM/OBR/BR; tryb ręczny faktycznie nadpisuje wyliczenia z kadry
- DEV: dodano powrót do automatycznego liczenia statystyk z zawodników i opcję „Kadra 99/99”
- DEV: usunięto widoczny licznik 1/7…7/7; odblokowanie nadal przez 7 stuknięć w wersję
- zachowana zgodność z sejwem 0.2; migracja wykonuje się automatycznie
- nowy cache PWA 0.3.0 build 3

## 0.2.0 (build 2)
- pierwsza wersja PWA
