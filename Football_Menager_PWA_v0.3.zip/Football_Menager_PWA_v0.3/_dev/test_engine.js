const FM=require('../engine.js');
const c=FM.createCareer({name:'FC Test',city:'Test',stadium:'Arena',capacity:1000,budget:100000});
if(c.fixtures.length!==90) throw new Error('fixtures '+c.fixtures.length);
if(FM.standings(c).length!==10) throw new Error('clubs');
FM.devUpdateClub(c,{budget:999983475681,reputation:20,stadiumCapacity:60000,attack:99,midfield:99,defense:99,goalkeeping:99});
let r=FM.userSquadRatings(c);
if(Math.round(r.attack)!==99||Math.round(r.overall)!==99) throw new Error('DEV ratings not applied '+JSON.stringify(r));
for(let round=0;round<18;round++){
  const f=FM.nextUserFixture(c); if(!f) throw new Error('missing fixture '+round);
  FM.startLiveMatch(c,'balanced');
  FM.advanceLiveMatch(c,'balanced',120);
  if(!c.activeMatch.finished||!c.activeMatch.finalized) throw new Error('match not finished');
  FM.acknowledgeLiveMatch(c);
}
if(!c.fixtures.every(f=>f.played)) throw new Error('season incomplete');
if(c.clubs.some(x=>x.played!==18)) throw new Error('played mismatch '+c.clubs.map(x=>x.played));
const before=c.season;const ns=FM.startNewSeason(c);if(!ns.ok||c.season!==before+1)throw new Error('new season');
console.log('OK', {version:FM.VERSION, fixtures:c.fixtures.length, season:c.season, ratingMode:FM.userClub(c).ratingMode, budget:FM.userClub(c).budget});
